class OrderWithSupplier(object):
    def __init__(self, topping, supplier, location):
        self.topping = topping
        self.supplier = supplier
        self.location = location